#Calculator (Swift)
A small calculator app written in Apple's language swift
