//
//  AppDelegate.h
//  Calculator-ObjectiveC
//
//  Created by Anthony Walker on 8/16/15.
//  Copyright (c) 2015 Anthony Walker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

